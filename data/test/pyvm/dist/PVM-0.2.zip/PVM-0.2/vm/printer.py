def print_s(stack):
	print stack
def print_str(i, l):
	toprint = l[i + 1].replace("\"'", '')
	print toprint
def print_s(stack):
	print stack

class VMError(Exception):
	pass